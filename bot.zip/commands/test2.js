const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
let headembed = new Discord.RichEmbed()
  .setAuthor(`Coin Flip`)
  .addField(`Result`, `You flipped a: **Heads**!`)
  .setThumbnail(`${message.author.displayAvatarURL}`)
  .setColor("RANDOM");
  .setFooter('Invite the bot `${bot.generateInvite().then(link => {msg.channel.send(link)})}`')
  message.channel.send(headembed)
}
bot.generateInvite().then(link => {msg.channel.send(link)})

module.exports.help = {
  name: "test2"
}
