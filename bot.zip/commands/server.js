const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {

  let invite = new Discord.RichEmbed()
      .setColor("RANDOM")
      .setTitle("Thanks for Thinking about joining our server")
      .addField('Here is a link', 'https://discord.gg/vqq45K2')
      .setTimestamp(new Date())
      .setFooter(`requested by ${message.author.tag}`);


      let server_message = new Discord.RichEmbed()
      .setColor('RANDOM')
      .setTitle(':D Check Direct Messages :D')
      .addField('Thanks For Supporting our bot', 'Please if you have any issues Contact Our support :D')
      .setTimestamp(new Date)
      .setFooter(`requested by ${message.author.tag}`);

message.author.send(invite);
message.channel.send(server_message);

}



 module.exports.help = {
   name: "server"
 }
