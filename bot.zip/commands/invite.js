// const Discord = require('discord.js');
//
// module.exports.run = async (client, message, args) => {
//
//   let invite = new Discord.RichEmbed()
//       .setColor("RANDOM")
//       .setTitle("Thanks for inviting our bot :D")
//       .addField('Here is a link', 'https://discordapp.com/api/oauth2/authorize?client_id=502132503470014474&permissions=2146958839&scope=bot')
//       .setTimestamp(new Date())
//       .setFooter(`requested by ${message.author.tag}`);
//
//
//       let server_message = new Discord.RichEmbed()
//       .setColor('RANDOM')
//       .setTitle(':D Check Direct Messages :D')
//       .addField('Thanks For Supporting our bot', 'Please if you have any issues Contact Our support :D')
//       .setTimestamp(new Date)
//       .setFooter(`requested by ${message.author.tag}`);
//
// message.author.send(invite);
// message.channel.send(server_message);
//
// }
//
//
//
//  module.exports.help = {
//    name: "invite"
//  }
