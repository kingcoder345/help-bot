const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {

client.channel.get("480439804501164044").send("Test")
message.channel.send("worked :D")

module.exports.help = {
    name: "test",
    category: "MODERATION",
}
