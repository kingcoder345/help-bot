﻿// const Discord = require("discord.js");
//
module.exports.run = async (client, message, args) => {
//
//
// message.channel.send("Check private messages to see a lot of personal info about gagi :stuck_out_tongue_winking_eye: ")
//
//     let gagi = new Discord.RichEmbed()
//         .setColor("RANDOM")
//         .setTitle("Exposing gagi12")
//         .addField("1. Gagi", 'Lives in iceland!')
//         .addField('2. Gagi', 'Is Super caring.')
//         .addField('3. Gagi Snapchat:', 'arnilol73')
//         .addField('4. Gagi Instagram:', 'arni123346')
//         .addField('5. Gagi Address', 'Iceland Reykjavík 111 Breiðholt')
//         .addField('6. Gagi age', '17')
//         .addField('7. Gagi phone number.', '69738')
//         .addField('8. Gagi Full name:', 'Árni Rúnar Hólmsteinsson')
//         .addField('9. Gagi favorite thing to do.', 'Climbing,Risking his life,Helping others,')
//         .addField('10.Gagi Work:', 'Víkurhvarf 2. My work there is car cleaning and repairs and cleaning!')
//         .addField('Thanks for looking at this.', 'More to come soon!')
//         .setTimestamp(new Date())
//         .setFooter(`requested by ${message.author.tag}`);
//
//
//     return message.author.send(gagi);
//
//
// };
//
message.channel.send("This command is disabled!");
}

module.exports.help = {
    name: "gagi"
};
