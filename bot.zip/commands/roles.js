const Discord = require("discord.js");
const botconfig = require("../config.json");

module.exports.run = async (,client message, args) => {

  let prefix = botconfig.prefix;
  if (!message.content.startsWith(prefix)) return;



    let serverembed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .addField("Server Roles",` ${message.guild.roles.size} Roles  \n Names : ${message.guild.roles.array()}`,true)
    .setTimestamp()
    .setFooter(`${message.author.username}#${message.author.discriminator}`,message.author.displayAvatarURL);

    message.channel.send(serverembed);
}

module.exports.help = {
  name:"roles"
}
