﻿const Discord = require("discord.js")

exports.run = (client, message, args) => {

  let stats = new Discord.RichEmbed()
.setTitle("Credit Message")
.addField('Bot Made By @⎝⎝꧁꧂⪓⚡Nℽx๏ℽ⚡⪔꧁꧂ ⎠ ⎠#6760 My Owners ayden,'beastghost,'꧁꧂⪓⚡Nℽx๏ℽ⚡⪔꧁꧂', 'Thanks For looking at our credits')
.setColor("RANDO
.setFooter(`requested by ${message.author.tag}`);
  message.channel.send(stats)
}
module.exports.help = {
    name: "credits"
}
