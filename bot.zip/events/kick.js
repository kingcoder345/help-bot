const Discord = require("discord.js");

module.exports.run = async (client,  message, args) => {
let kUser =  message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
  if(!kUser) return message.channel.send("Cant find user!");
  let kReason = args.join(" ").slice(22);
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Oof it seems like you no has da perms! please try again soon or when you have the perms.");
  if(kUser.hasPermission("MANAGE_MESSAGES")) return message.channel.send("You can't kick that person! Only in your dreams..");

  let kickEmbed = new Discord.RichEmbed()
   .setDescription("**Kick**")
   .setColor("#e26ce1")
   .addField("Kicked User", `${kUser} With ID: ${kUser.id}`)
   .addField("Reason", kReason)
   .addField("Kicked By", `<@${message.author.id}> with ID: ${message.author.id}`)
   .addField("Kicked in", message.channel)
   .addField("Time", message.createdAt)

   let kickChannel = message.guild.channels.find(`name`, "incidents");
   if(!kickChannel) return message.channel.send("Cant find incidents channel.");

   message.guild.member(kUser).kick(kReason);
   kickChannel.send(kickEmbed);

}
module.exports.help = {
  name: "kick"
}
