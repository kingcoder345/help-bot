// const Discord = require("discord.js");
//
// module.exports.run = async (client,  message, args) => {
//  if(!message.member.hasPermission("MANAGE_MEMBERS")) return message.reply("Sorry You Dont Have permission!");
//  let rMember = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[9]);
//  if(!rMember) return message.reply("Could not find the user!");
//  let role = args.join(" ").slice(22);
//  if (!role) return message.reply("Please be specific about which role!");
//  if gRole = message.guild.roles.find(`name`, role);
//  if(!gRole) return message.reply("Could not find the role!");
//
//  if(rMember.roles.has(gRole.id));
//  await(rMember.addRole(gRole.id));
//
//  try{
//    rMember.send(`Congrats, You have been given the role ${gRole.name}`);
//  }catch(e){
//  message.channel.send(`Congrats, ${rMember.id} You have been given the role ${gRole.name}`);
// }
// module.exports.help = {
//   name: "addrole"
// }
