// const Discord = require("discord.js");
//
// module.exports.run = async (client, message, args) => {
//
// message.channel.send('Suki **Is** Love')
// message.channel.send('Suki **Is** life')
// message.channel.send('Suki **Is** Bae');
//
//
// }
//
// module.exports.help = {
//     name: "suki"
// };
